import random

class Ship:
    def __init__(self, size):
        self.size = size
        self.hit_count = 0

    def is_sunk(self):
        return self.hit_count >= self.size

class Carrier(Ship):
    def __init__(self):
        super().__init__(size=5)

class Battleship(Ship):
    def __init__(self):
        super().__init__(size=4)

class Cruiser(Ship):
    def __init__(self):
        super().__init__(size=3)

class Submarine(Ship):
    def __init__(self):
        super().__init__(size=3)

class Destroyer(Ship):
    def __init__(self):
        super().__init__(size=2)

class BattleshipGame:
    def __init__(self, grid_file, winner_file):
        self.grid_file = grid_file
        self.winner_file = winner_file
        self.grid_size = self.read_grid_size()
        self.player1_grid = [['~' for _ in range(self.grid_size)] for _ in range(self.grid_size)]
        self.player2_grid = [['~' for _ in range(self.grid_size)] for _ in range(self.grid_size)]
        self.player1_ships = [Carrier(), Battleship(), Cruiser(), Submarine(), Destroyer()]
        self.player2_ships = [Carrier(), Battleship(), Cruiser(), Submarine(), Destroyer()]
        self.player1_hits = 0
        self.player2_hits = 0
        self.current_player = 1

    def read_grid_size(self):
      with open(self.grid_file, 'r') as file:
          return int(file.readline().strip())

    def write_winner(self, winner):
      with open(self.winner_file, 'a') as file:
          file.write(f"The winner is Player {winner}!\n")

    def print_grids(self):
        print("Player 1's Grid:")
        for row in self.player1_grid:
            print(' '.join(row))
        print("\nPlayer 2's Grid:")
        for row in self.player2_grid:
            print(' '.join(row))

    def place_ship(self, grid, ship):
                while True:
                    direction = random.choice(['horizontal', 'vertical'])
                    if direction == 'horizontal':
                        x = random.randint(0, self.grid_size - ship.size)
                        y = random.randint(0, self.grid_size - 1)
                    else:
                        x = random.randint(0, self.grid_size - 1)
                        y = random.randint(0, self.grid_size - ship.size)

                    valid_placement = True
                    for i in range(ship.size):
                        if direction == 'horizontal':
                            if grid[y][x + i] != '~':
                                valid_placement = False
                                break
                        else:
                            if grid[y + i][x] != '~':
                                valid_placement = False
                                break

                    if valid_placement:
                        for i in range(ship.size):
                            if direction == 'horizontal':
                                grid[y][x + i] = 'O'
                            else:
                                grid[y + i][x] = 'O'
                        break

    def take_turn(self, target_grid, target_player):
        while True:
            try:
                x = int(input("Enter x coordinate (0 to {}): ".format(self.grid_size - 1)))
                y = int(input("Enter y coordinate (0 to {}): ".format(self.grid_size - 1)))

                if 0 <= x < self.grid_size and 0 <= y < self.grid_size:
                    if target_grid[y][x] == '~':
                        print("Miss!")
                        target_grid[y][x] = 'M'
                    elif target_grid[y][x] == 'O':
                        print("Hit!")
                        target_grid[y][x] = 'X'
                        if target_player == 1:
                            self.player1_hits += 1
                        else:
                            self.player2_hits += 1
                    else:
                        print("Already guessed this position.")
                else:
                    print("Coordinates out of bounds.")

                break
            except ValueError:
                print("Invalid input. Please enter integers.")

    def play_game(self):
        print("Placing ships for Player 1...")
        for ship in self.player1_ships:
            self.place_ship(self.player1_grid, ship)
        print("Placing ships for Player 2...")
        for ship in self.player2_ships:
            self.place_ship(self.player2_grid, ship)

        while self.player1_hits < sum(ship.size for ship in self.player1_ships) and \
              self.player2_hits < sum(ship.size for ship in self.player2_ships):
            self.print_grids()
            print("Player {}'s turn".format(self.current_player))
            if self.current_player == 1:
                self.take_turn(self.player2_grid, 2)
                self.current_player = 2
            else:
                self.take_turn(self.player1_grid, 1)
                self.current_player = 1

        if self.player1_hits == sum(ship.size for ship in self.player1_ships):
            print("Player 1 wins!")
        else:
            print("Player 2 wins!")

if __name__ == '__main__':
    grid_file = 'grid_size.txt'
    winner_file = 'winner.txt'
    game = BattleshipGame(grid_file, winner_file)
    game.play_game()
    winner = 1 if game.player1_hits == sum(ship.size for ship in game.player1_ships) else 2
    game.write_winner(winner)